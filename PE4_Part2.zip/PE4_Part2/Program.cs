﻿// See https://aka.ms/new-console-template for more information

using System;

namespace PE4
{
    // Class Program
    // Author: Grace Ledford 
    // Purpose: Practice exercise 4 (last question)
    // Restrictions: None
    class Program
    {
        // Method: Main
        // Purpose: requests image limits from user and displays the chosen section of the image. Every image chosen fits in the same amount of space to maximize the viewable area.
        // Restrictions: None
        static void Main(string[] args)
        {
            double dStartImagCoord = 1.2;
            double dEndImagCoord = -1.2;
            string sStartImagCoord;
            string sEndImagCoord;
            Console.Write("Enter the starting coordinate for the imaginary plane (default = 1.2): ");
            sStartImagCoord = Console.ReadLine();

            // converts sStartImagCoord to dStartImagCoord.
            Console.Write($"Enter the ending coordinate for the imaginary plane (default = -1.2) and it must be less than {sStartImagCoord}: ");
            sEndImagCoord = Console.ReadLine();

            // converts sEndImagCoord to dEndImagCoord.
            // ensures the end is less than the start.
            double dImagDec = -1 * (dStartImagCoord - dEndImagCoord) / 48.0;
            double dStartRealCoord = -0.6;
            double dEndRealCoord = 1.77;
            string sStartRealCoord;
            string sEndRealCoord;
            Console.Write("Enter the starting coordinate for the real plane (default = -0.6): ");
            sStartRealCoord = Console.ReadLine();

            // converts sStartRealCoord to dStartRealCoord.
            Console.Write($"Enter the ending coordinate for the imaginary plane (default = 1.77) and it must be greater than {sStartRealCoord}: ");
            sEndRealCoord = Console.ReadLine();

            // converts sEndRealCoord to dEndRealCoord.
            // ensures the end is greater than the start.
            double dRealInc = (dEndRealCoord - dStartRealCoord) / 80.0;
            double imagCoord;
            for (imagCoord = dStartImagCoord; imagCoord >= dEndImagCoord; imagCoord -= dImagDec)
            {
                double realCoord;
                for (realCoord = dStartRealCoord; realCoord <= dEndRealCoord; realCoord += dRealInc)
                {
                }
            }
        }
    }
}
