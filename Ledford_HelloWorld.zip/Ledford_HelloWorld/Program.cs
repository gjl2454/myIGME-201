﻿// See https://aka.ms/new-console-template for more information

using System;

namespace HelloWorld
{
    // Class: Program
    // Author: Grace Ledford
    // Purpose: Intro assignment
    // Restrictions: None
    static class Program
    {
        // Method: Main
        // Purpose: Writes my name into the console, creates a string variable, and math calculations are done and printed to the console with the use of another variable.
        // Restrictions: None
        static void Main(string[] args)
        {
            Console.WriteLine("Grace Ledford");

            string numbClassesSoFar = "4";

            int sumOfFour = 2 + 2;
            Console.WriteLine("sumOfFour + sumOfFour = " + (sumOfFour + sumOfFour));
        }
    }
}



