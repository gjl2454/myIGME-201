﻿
using System;

namespace PE4
{
    // Class Program
    // Author: Grace Ledford 
    // Purpose: None
    // Restrictions: None
    static class Program
    {
        // Method: Main
        // Purpose: obtains two numbers from the user and displays them, but rejects any input where both numbers are greater than 10 and asks for two new numbers.
        // Restrictions: None
        static void Main(string[] args)
        {
            int var1 = 2;
            int var2 = 7;
            bool beGood = false;

            while (true)
            {
                while (true)
                {
                    // asks user to pick 2 numbers.
                    Console.WriteLine("Choose numbers where either are greater than 10 but not both:");
                    // string variables are created and initialized. 
                    string sVar1;
                    string sVar2;
                    sVar1 = Console.ReadLine();
                    sVar2 = Console.ReadLine();
                    // the variables that were created are then parsed. 
                    if (int.TryParse(sVar1, out var1) && int.TryParse(sVar2, out var2))
                    {
                        // if statement ends.
                        break;
                    }
                }
                // numbers are chosen and outcome is displayed by the boolean. 
                if ((var1 > 10 || var2 > 10) && !(var1 > 10 && var2 > 10))
                {
                    Console.WriteLine("Numbers are good");
                    beGood = true;
                }
                else
                {
                    Console.WriteLine("Rewrite numbers");
                }
                if ((var1 > 10) ^ (var2 > 10))
                {
                    Console.WriteLine("Numbers are good");
                    beGood = true;
                }
                else
                {
                    Console.WriteLine("Rewrite numbers");
                }
                if (beGood == true)
                {
                    // end of the if statement. 
                    break;
                }
            }
        }
    }
}



        