﻿// See https://aka.ms/new-console-template for more information

using System;

namespace ConsoleApp1
{
    // Class: Program
    // Author: Grace Ledford
    // Purpose: None
    // Restrictions: None
    static class Program
    {
        // Method: Main
        // Purpose: Convert string variables into numbers. 
        // Restrictions: None
        static void Main(string[] args)
        {
            string apples = "";
            int napples = 5;

            string oranges = "";
            int noranges = 6;

            string lemons = "";
            int nlemons = 10;

            string limes = "";
            int nlimes = 2;

            // get the first from the user
            // be in a loop until the user types a valid number
            while (true)
            {

                // prompt the user to enter a number
                Console.Write("Enter a number: ");

                // read user input into a string
                apples = Console.ReadLine();


                // be in a loop until the user types a valid number
                try
                {
                    napples = Convert.ToInt32(apples);
                    break;
                }
                catch
                {
                    Console.WriteLine("That's not a number!");
                }
            }

            // get the second from the user
            // be in a loop until the user types a valid number
            while (true)
            {

                // prompt the user to enter a number
                Console.Write("Enter a number: ");

                // read user input into a string
                oranges = Console.ReadLine();


                // be in a loop until the user types a valid number
                try
                {
                    noranges = Convert.ToInt32(oranges);
                    break;
                }
                catch
                {
                    Console.WriteLine("That's not a number!");
                }
            }

            // get the third from the user
            // be in a loop until the user types a valid number
            while (true)
            {

                // prompt the user to enter a number
                Console.Write("Enter a number: ");

                // read user input into a string
                lemons = Console.ReadLine();


                // be in a loop until the user types a valid number
                try
                {
                    nlemons = Convert.ToInt32(lemons);
                    break;
                }
                catch
                {
                    Console.WriteLine("That's not a number!");
                }
            }

            // get the fourth from the user
            // be in a loop until the user types a valid number
            while (true)
            {

                // prompt the user to enter a number
                Console.Write("Enter a number: ");

                // read user input into a string
                limes = Console.ReadLine();


                // be in a loop until the user types a valid number
                try
                {
                    nlimes = Convert.ToInt32(limes);
                    break;
                }
                catch
                {
                    Console.WriteLine("That's not a number!");
                }
            }
            Console.WriteLine("Product of all 4 variables: " + (napples * noranges * nlemons * nlimes));

        }
    }
}
